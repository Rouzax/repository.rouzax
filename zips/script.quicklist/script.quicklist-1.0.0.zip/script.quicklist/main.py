# -*- coding: utf-8 -*-
"""
QuickList - Context menu addon for managing TV show playlist membership.

Entry point for the context menu action and selector dialog.
"""
from typing import List
import sys

import xbmc
import xbmcgui
import xbmcaddon

from resources.lib.playlist_manager import (
    get_tvshow_playlists,
    apply_changes,
    SmartPlaylist
)

ADDON = xbmcaddon.Addon()
LOG_PREFIX = '[QuickList]'


def log(message: str) -> None:
    """Log a message to Kodi's log file."""
    xbmc.log('{} {}'.format(LOG_PREFIX, message), xbmc.LOGINFO)


def lang(string_id: int) -> str:
    """Get localized string."""
    return ADDON.getLocalizedString(string_id)


def get_selected_show_title() -> str:
    """Get the title of the currently selected TV show."""
    return xbmc.getInfoLabel('ListItem.Title')


def get_whitelist() -> List[str]:
    """Get the playlist whitelist from settings."""
    try:
        whitelist_str = ADDON.getSetting('playlist_whitelist')
        if not whitelist_str:
            return []
        return [name.strip() for name in whitelist_str.split('|') if name.strip()]
    except Exception:
        log('Could not read whitelist setting, using default (all playlists)')
        return []


def filter_playlists(playlists: List[SmartPlaylist], whitelist: List[str]) -> List[SmartPlaylist]:
    """
    Filter playlists based on whitelist.

    Args:
        playlists: All available playlists
        whitelist: List of allowed playlist names (empty = allow all)

    Returns:
        Filtered list of playlists
    """
    if not whitelist:
        return playlists

    whitelist_lower = [name.lower() for name in whitelist]
    return [p for p in playlists if p.name.lower() in whitelist_lower]


def show_playlist_dialog(title: str) -> None:
    """
    Show multi-select dialog for playlist membership.

    Args:
        title: The TV show title to manage
    """
    log('Opening dialog for show: {}'.format(title))

    all_playlists = get_tvshow_playlists()
    whitelist = get_whitelist()
    playlists = filter_playlists(all_playlists, whitelist)

    if whitelist:
        log('Whitelist active: {} playlists after filtering'.format(len(playlists)))

    if not playlists:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            lang(32002),  # No TV show playlists found
            xbmcgui.NOTIFICATION_INFO
        )
        return

    # Build list and track which are pre-selected
    playlist_names = [p.name for p in playlists]
    preselected = [i for i, p in enumerate(playlists) if p.contains(title)]

    log('Show is in {} playlists'.format(len(preselected)))

    # Show multi-select dialog
    dialog = xbmcgui.Dialog()
    selected = dialog.multiselect(
        '{} "{}"'.format(lang(32001), title),  # Select playlists for "Show"
        playlist_names,
        preselect=preselected
    )

    if selected is None:
        log('Dialog cancelled')
        return

    # Apply changes
    added, removed = apply_changes(playlists, title, selected, preselected)

    log('Changes applied: +{} -{}'.format(added, removed))

    # Show result notification
    if added or removed:
        msg = lang(32003)  # Updated playlists
        if added and removed:
            msg = '+{} / -{}'.format(added, removed)
        elif added:
            msg = '+{}'.format(added)
        else:
            msg = '-{}'.format(removed)

        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            msg,
            xbmcgui.NOTIFICATION_INFO
        )
    else:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            lang(32004),  # No changes made
            xbmcgui.NOTIFICATION_INFO
        )


def main() -> None:
    """Main entry point."""
    # Check for selector mode
    if len(sys.argv) > 1 and sys.argv[1] == 'selector':
        from resources.lib.selector import show_selector
        show_selector()
        # Reopen settings after selector closes
        ADDON.openSettings()
        return
    
    # Normal context menu mode
    title = get_selected_show_title()

    if not title:
        log('No show title found')
        return

    show_playlist_dialog(title)


if __name__ == '__main__':
    main()
