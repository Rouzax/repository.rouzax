# -*- coding: utf-8 -*-
"""
Smart playlist manager for QuickList.

Handles parsing, querying, and modifying Kodi smart playlists (.xsp files).
"""
from typing import List, Optional, Tuple
import xml.etree.ElementTree as ET
import os

import xbmc
import xbmcvfs

LOG_PREFIX = '[QuickList]'


def log(message: str) -> None:
    """Log a message to Kodi's log file."""
    xbmc.log('{} {}'.format(LOG_PREFIX, message), xbmc.LOGINFO)


class SmartPlaylist:
    """Represents a smart playlist and its title rules."""

    def __init__(self, filepath: str, name: str, titles: List[str], has_title_rule: bool):
        self.filepath = filepath
        self.name = name
        self.titles = titles
        self.has_title_rule = has_title_rule

    def contains(self, title: str) -> bool:
        """Check if this playlist contains the given title."""
        return title in self.titles


def get_playlist_directory() -> str:
    """Get the path to Kodi's video playlists directory."""
    return xbmcvfs.translatePath('special://profile/playlists/video/')


def parse_playlist(filepath: str) -> Optional[SmartPlaylist]:
    """
    Parse a smart playlist file and extract title rules.

    Args:
        filepath: Full path to the .xsp file

    Returns:
        SmartPlaylist object if valid TV show playlist, None otherwise
    """
    try:
        with xbmcvfs.File(filepath, 'r') as f:
            content = f.read()

        root = ET.fromstring(content)

        # Only process TV show playlists
        if root.get('type') != 'tvshows':
            return None

        # Get playlist name
        name_elem = root.find('n')
        if name_elem is None or not name_elem.text:
            # Fallback to filename
            name = os.path.splitext(os.path.basename(filepath))[0]
        else:
            name = name_elem.text

        # Find title rules and extract values
        titles = []  # type: List[str]
        has_title_rule = False

        for rule in root.findall('rule'):
            if rule.get('field') == 'title' and rule.get('operator') == 'is':
                has_title_rule = True
                for value in rule.findall('value'):
                    if value.text:
                        titles.append(value.text)

        return SmartPlaylist(filepath, name, titles, has_title_rule)

    except ET.ParseError as e:
        log('Failed to parse playlist {}: {}'.format(filepath, e))
        return None
    except Exception as e:
        log('Error reading playlist {}: {}'.format(filepath, e))
        return None


def get_tvshow_playlists() -> List[SmartPlaylist]:
    """
    Get all TV show smart playlists from Kodi's playlist directory.

    Returns:
        List of SmartPlaylist objects, sorted by name
    """
    playlist_dir = get_playlist_directory()
    playlists = []  # type: List[SmartPlaylist]

    if not xbmcvfs.exists(playlist_dir):
        log('Playlist directory not found: {}'.format(playlist_dir))
        return playlists

    dirs, files = xbmcvfs.listdir(playlist_dir)

    for filename in files:
        if not filename.lower().endswith('.xsp'):
            continue

        filepath = os.path.join(playlist_dir, filename)
        playlist = parse_playlist(filepath)

        if playlist:
            playlists.append(playlist)

    log('Found {} TV show playlists'.format(len(playlists)))
    return sorted(playlists, key=lambda p: p.name.lower())


def update_playlist(playlist: SmartPlaylist, title: str, add: bool) -> bool:
    """
    Add or remove a title from a playlist's title rules.

    Args:
        playlist: The playlist to modify
        title: The show title to add or remove
        add: True to add, False to remove

    Returns:
        True if the file was modified, False otherwise
    """
    action = 'Adding' if add else 'Removing'
    log('{} "{}" {} "{}"'.format(action, title, 'to' if add else 'from', playlist.name))

    try:
        with xbmcvfs.File(playlist.filepath, 'r') as f:
            content = f.read()

        # Use parser that preserves comments (Python 3.8+)
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
        root = ET.fromstring(content, parser=parser)

        # Find existing title rule
        title_rule = None
        for rule in root.findall('rule'):
            if rule.get('field') == 'title' and rule.get('operator') == 'is':
                title_rule = rule
                break

        if add:
            if title_rule is None:
                # Create new title rule - insert before <order> if present
                title_rule = ET.Element('rule')
                title_rule.set('field', 'title')
                title_rule.set('operator', 'is')
                title_rule.text = '\n        '
                title_rule.tail = '\n    '

                order_elem = root.find('order')
                if order_elem is not None:
                    # Insert before order
                    order_idx = list(root).index(order_elem)
                    root.insert(order_idx, title_rule)
                else:
                    root.append(title_rule)

            # Check if title already exists
            existing = [v.text for v in title_rule.findall('value') if v.text]
            if title in existing:
                log('Title already in playlist, skipping')
                return False

            # Add value element
            value_elem = ET.SubElement(title_rule, 'value')
            value_elem.text = title
            value_elem.tail = '  '
            
            # Add comment after value
            comment = ET.Comment(' Added by QuickList ')
            title_rule.append(comment)
            comment.tail = '\n    '
            
            # Fix indentation: only update the element immediately before the new value
            children = list(title_rule)
            value_index = children.index(value_elem)
            
            if value_index == 0:
                # First child - set rule's text for indentation
                title_rule.text = '\n        '
            else:
                # Update the element right before our new value
                prev_child = children[value_index - 1]
                prev_child.tail = '\n        '
        else:
            # Remove title
            if title_rule is None:
                log('No title rule found, nothing to remove')
                return False

            found = False
            children = list(title_rule)
            for i, child in enumerate(children):
                if child.tag == 'value' and child.text == title:
                    # Check if next sibling is a QuickList comment
                    if i + 1 < len(children):
                        next_child = children[i + 1]
                        if callable(next_child.tag):  # Comment check
                            if 'Added by QuickList' in (next_child.text or ''):
                                title_rule.remove(next_child)
                    title_rule.remove(child)
                    found = True
                    break

            if not found:
                log('Title not found in playlist')
                return False

            # Remove empty title rule
            if not title_rule.findall('value'):
                log('Removing empty title rule')
                root.remove(title_rule)

        # Write back with proper XML declaration
        xml_str = ET.tostring(root, encoding='unicode')
        output = '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n' + xml_str

        with xbmcvfs.File(playlist.filepath, 'w') as f:
            success = f.write(output)

        if success:
            log('Successfully updated playlist')
            return True
        else:
            log('Failed to write playlist file')
            return False

    except ET.ParseError as e:
        log('Failed to parse playlist {}: {}'.format(playlist.filepath, e))
        return False
    except Exception as e:
        log('Error updating playlist {}: {}'.format(playlist.name, e))
        return False


def apply_changes(
    playlists: List[SmartPlaylist],
    title: str,
    selected_indices: List[int],
    original_indices: List[int]
) -> Tuple[int, int]:
    """
    Apply playlist membership changes for a show.

    Args:
        playlists: List of all playlists
        title: The show title
        selected_indices: Indices of playlists that should contain the show
        original_indices: Indices of playlists that originally contained the show

    Returns:
        Tuple of (added_count, removed_count)
    """
    added = 0
    removed = 0

    selected_set = set(selected_indices)
    original_set = set(original_indices)

    # Add to newly selected playlists
    for idx in selected_set - original_set:
        if update_playlist(playlists[idx], title, add=True):
            added += 1

    # Remove from unselected playlists
    for idx in original_set - selected_set:
        if update_playlist(playlists[idx], title, add=False):
            removed += 1

    return added, removed
