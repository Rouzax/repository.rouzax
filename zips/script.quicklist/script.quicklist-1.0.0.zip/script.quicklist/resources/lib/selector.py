# -*- coding: utf-8 -*-
"""
Playlist selector dialog for QuickList.

Shows a multi-select dialog of TV show playlists and saves the selection
to addon settings.
"""
from typing import List

import xbmcgui
import xbmcaddon

from resources.lib.playlist_manager import get_tvshow_playlists, log

ADDON = xbmcaddon.Addon()


def lang(string_id: int) -> str:
    """Get localized string."""
    return ADDON.getLocalizedString(string_id)


def get_current_whitelist() -> List[str]:
    """Get the current playlist whitelist from settings."""
    try:
        whitelist_str = ADDON.getSetting('playlist_whitelist')
        if not whitelist_str:
            return []
        return [name.strip() for name in whitelist_str.split('|') if name.strip()]
    except Exception:
        return []


def save_whitelist(selected_names: List[str]) -> None:
    """Save the playlist whitelist to settings."""
    # Save the actual whitelist (pipe-separated for internal storage)
    whitelist_str = '|'.join(selected_names) if selected_names else ''
    ADDON.setSetting('playlist_whitelist', whitelist_str)
    
    # Update display setting
    if selected_names:
        display_text = lang(32014) % len(selected_names)  # "%d playlists selected"
    else:
        display_text = lang(32015)  # "All playlists"
    ADDON.setSetting('playlist_whitelist_display', display_text)
    
    log('Whitelist saved: {} playlists'.format(len(selected_names)))


def show_selector() -> None:
    """Show the playlist selection dialog."""
    log('Opening playlist selector')
    
    playlists = get_tvshow_playlists()
    
    if not playlists:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            lang(32002),  # No TV show playlists found
            xbmcgui.NOTIFICATION_INFO
        )
        return
    
    # Get current selection
    current_whitelist = get_current_whitelist()
    
    # Build list and preselect
    playlist_names = [p.name for p in playlists]
    
    # If whitelist is empty, nothing is preselected (means "all")
    # If whitelist has items, preselect those
    if current_whitelist:
        preselected = [i for i, p in enumerate(playlists) 
                       if p.name in current_whitelist]
    else:
        preselected = []
    
    # Show multi-select dialog
    dialog = xbmcgui.Dialog()
    selected = dialog.multiselect(
        lang(32016),  # "Select playlists to show"
        playlist_names,
        preselect=preselected
    )
    
    if selected is None:
        log('Selector cancelled')
        return
    
    # Build selected names list
    selected_names = [playlists[i].name for i in selected]
    
    # Save selection
    save_whitelist(selected_names)
    
    log('Selected {} playlists'.format(len(selected_names)))


if __name__ == '__main__':
    show_selector()
