#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  Copyright (C) 2024-2026 Rouzax
#
#  SPDX-License-Identifier: GPL-3.0-or-later
#  See LICENSE.txt for more information.
#

"""
EasyTV Library Monitor.

Monitors Kodi library and settings changes to keep the service in sync.
Extracted from service.py as part of modularization.

Logging:
    Module: library_monitor
    Events: None (debug/info logging only, no formal events)
"""
from __future__ import annotations

import ast
import time
from typing import TYPE_CHECKING, Callable, List, Optional

import xbmc
import xbmcgui

from resources.lib.constants import (
    PROP_ART_FETCHED,
    SCAN_COOLDOWN_SECONDS,
    WATCHED_PLAYCOUNT,
)
from resources.lib.data.queries import build_episode_show_id_query
from resources.lib.utils import get_logger, json_query

if TYPE_CHECKING:
    from resources.lib.utils import StructuredLogger


# Type aliases for callbacks
SettingsReloadCallback = Callable[[], None]
GetEpisodesCallback = Callable[[List[int]], None]
GetRandomShowsCallback = Callable[[], List[int]]


class LibraryMonitor(xbmc.Monitor):
    """
    Monitors Kodi library updates and settings changes.
    
    Responds to:
    - Settings changes: Triggers settings reload
    - Library scan completion: Records timestamp for daemon cooldown polling
    - VideoLibrary.OnUpdate notifications: Handles watched/unwatched changes

    Args:
        window: The Kodi home window for property access.
        on_settings_changed: Callback when settings change.
        get_random_order_shows: Callback to get current random order shows list.
        on_refresh_show: Callback to refresh a specific show's episodes.
        on_playing_episode_watched: Callback(show_id, episode_id) when a tracked
            episode is marked watched. Called before on_refresh_show to allow the
            daemon to complete tracking before the refresh blocks the loop.
        logger: Optional logger instance.
    """

    def __init__(
        self,
        window: xbmcgui.Window,
        on_settings_changed: SettingsReloadCallback,
        get_random_order_shows: GetRandomShowsCallback,
        on_refresh_show: GetEpisodesCallback,
        on_playing_episode_watched: Callable[[int, int], None],
        logger: Optional[StructuredLogger] = None,
    ):
        """Initialize the library monitor with callbacks."""
        super().__init__()

        self._window = window
        self._on_settings_changed = on_settings_changed
        self._get_random_order_shows = get_random_order_shows
        self._on_refresh_show = on_refresh_show
        self._on_playing_episode_watched = on_playing_episode_watched
        self._log = logger or get_logger('library_monitor')
        
        # Notification data storage
        self._notification_data: dict = {}

        # Scan cooldown state
        self.scan_finished_at: Optional[float] = None
        self.is_scanning: bool = False
    
    def onSettingsChanged(self) -> None:
        """Handle settings changes by triggering a reload."""
        self._on_settings_changed()
    
    def onScanStarted(self, library: str) -> None:
        """
        Handle library scan start.

        Tracks that a video scan is in progress so the cooldown timer
        does not fire while the database is still being updated.

        Args:
            library: The library being scanned ('video' or 'music').
        """
        if library == 'video':
            self.is_scanning = True
            self._log.debug(
                "Library scan started",
                event="library.scan_started"
            )

    def onScanFinished(self, library: str) -> None:
        """
        Handle library scan completion.

        Records the finish timestamp for the cooldown guard instead of
        triggering an immediate refresh. The daemon polls
        consume_scan_update() and only refreshes after the cooldown
        elapses with no new scan activity.

        Also clears the art cache flag so new shows get their art
        fetched when Browse mode opens.

        Args:
            library: The library that was scanned ('video' or 'music').
        """
        if library == 'video':
            self.is_scanning = False
            self.scan_finished_at = time.monotonic()
            self._log.info(
                "Library scan finished, cooldown started",
                event="library.scan_finished"
            )
            self._window.clearProperty(PROP_ART_FETCHED)

    def consume_scan_update(self) -> bool:
        """
        Check whether a scan cooldown has elapsed and consume it.

        Called by the daemon on each loop tick. Returns True (once) when:
        - A scan has finished (scan_finished_at is set)
        - No scan is currently in progress
        - At least SCAN_COOLDOWN_SECONDS have passed since the last finish

        When True is returned, scan_finished_at is reset to None so the
        update is consumed exactly once.

        Returns:
            True if a library refresh should run now, False otherwise.
        """
        if self.scan_finished_at is None or self.is_scanning:
            return False
        elapsed = time.monotonic() - self.scan_finished_at
        if elapsed >= SCAN_COOLDOWN_SECONDS:
            self.scan_finished_at = None
            return True
        return False
    
    def onNotification(self, _sender: str, method: str, data: str) -> None:
        """
        Handle Kodi notifications.
        
        Processes VideoLibrary.OnUpdate notifications to detect:
        - Episodes marked as watched: Refreshes show tracking
        - Episodes marked as unwatched: Refreshes show tracking
        
        Args:
            _sender: The notification sender (unused, required by Kodi API).
            method: The notification method/type.
            data: JSON string with notification data.
        """
        # Only process VideoLibrary.OnUpdate notifications
        if method != 'VideoLibrary.OnUpdate':
            return
        
        # Parse notification data
        try:
            self._notification_data = ast.literal_eval(data)
        except (ValueError, SyntaxError):
            return
        
        # Check for valid episode update with playcount
        if 'item' not in self._notification_data:
            return
        if 'playcount' not in self._notification_data:
            return
        if 'type' not in self._notification_data['item']:
            return
        if self._notification_data['item']['type'] != 'episode':
            return
        
        episode_id = self._notification_data['item']['id']
        playcount = self._notification_data['playcount']
        
        self._log.debug(
            "Episode update notification",
            episode_id=episode_id,
            playcount=playcount
        )
        
        if playcount >= WATCHED_PLAYCOUNT:
            self._handle_episode_watched(episode_id)
        elif playcount == 0:
            self._handle_episode_unwatched(episode_id)
    
    def _handle_episode_watched(self, episode_id: int) -> None:
        """
        Handle an episode being marked as watched.
        
        Checks if the episode is in the current show's ondeck/offdeck list
        and refreshes the show's tracking data if so.
        
        Args:
            episode_id: The ID of the watched episode.
        """
        self._log.debug("Watched status change detected", data=self._notification_data)
        
        # Get the show ID for this episode
        result = json_query(build_episode_show_id_query(episode_id), True)
        if 'episodedetails' not in result:
            return
        
        show_id = result['episodedetails']['tvshowid']
        
        random_order_shows = self._get_random_order_shows()
        proceed = False
        
        if show_id in random_order_shows:
            # For random order shows, check both ondeck and offdeck
            ondeck_list = self._get_episode_list(show_id, 'ondeck_list')
            offdeck_list = self._get_episode_list(show_id, 'offdeck_list')
            
            if episode_id in ondeck_list or episode_id in offdeck_list:
                proceed = True
        else:
            # For sequential shows, only check ondeck
            ondeck_list = self._get_episode_list(show_id, 'ondeck_list')
            if episode_id in ondeck_list:
                proceed = True
        
        if proceed:
            # Notify daemon before refresh — the refresh blocks the daemon loop
            # for 1-2 seconds, which can cause the position check to miss the
            # threshold. This callback lets the daemon complete tracking first.
            self._on_playing_episode_watched(show_id, episode_id)
            self._log.info(
                "Refreshing show after watched",
                event="library.refresh_watched",
                show_id=show_id,
                episode_id=episode_id
            )
            self._on_refresh_show([show_id])
    
    def _handle_episode_unwatched(self, episode_id: int) -> None:
        """
        Handle an episode being marked as unwatched.
        
        Refreshes the show's tracking data to pick up the now-unwatched episode.
        
        Args:
            episode_id: The ID of the unwatched episode.
        """
        self._log.debug("Episode marked unwatched", data=self._notification_data)
        
        result = json_query(build_episode_show_id_query(episode_id), True)
        if 'episodedetails' in result:
            show_id = result['episodedetails']['tvshowid']
            self._log.info(
                "Refreshing show after unwatched",
                event="library.refresh_unwatched",
                show_id=show_id,
                episode_id=episode_id
            )
            self._on_refresh_show([show_id])
    
    def _get_episode_list(self, show_id: int, list_name: str) -> List[int]:
        """
        Get an episode list from window properties.
        
        Args:
            show_id: The TV show ID.
            list_name: Either 'ondeck_list' or 'offdeck_list'.
        
        Returns:
            List of episode IDs, or empty list if not found/invalid.
        """
        property_name = f"EasyTV.{show_id}.{list_name}"
        property_value = self._window.getProperty(property_name)
        
        try:
            return ast.literal_eval(property_value)
        except (ValueError, SyntaxError):
            return []
