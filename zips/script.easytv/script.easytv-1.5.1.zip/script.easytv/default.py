#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  Copyright (C) 2024-2026 Rouzax
#
#  SPDX-License-Identifier: GPL-3.0-or-later
#  See LICENSE.txt for more information.
#
"""EasyTV Main Entry Point."""

if __name__ == "__main__":
    from resources.lib.ui.main import main
    main()
