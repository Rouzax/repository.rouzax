#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  Copyright (C) 2024-2026 Rouzax
#
#  SPDX-License-Identifier: GPL-3.0-or-later
#  See LICENSE.txt for more information.
#
"""
EasyTV Background Service Logic.

Monitors playback, updates episode tracking, and provides next episode prompts.
Modernized for Kodi 21+ (Nexus/Omega).

Logging:
    Module: service
    Events:
        - service.start (INFO): Service has started
        - service.stop (INFO): Service has stopped
"""

import xbmc
import xbmcaddon
from resources.lib.utils import get_logger, parse_version, StructuredLogger
from resources.lib.service.daemon import ServiceDaemon


def _get_device_name() -> str:
    """Get device identifier for logging. Prefers friendly name, falls back to hostname."""
    friendly = xbmc.getInfoLabel('System.FriendlyName')
    if friendly:
        return friendly
    # Fallback to hostname if friendly name not set
    import socket
    try:
        return socket.gethostname()
    except Exception:
        return 'unknown'


def _get_kodi_version() -> str:
    """Get Kodi version string (e.g., '21.1')."""
    # BuildVersion format: "21.1 (21.1.0) Git:..." - extract first part
    build = xbmc.getInfoLabel('System.BuildVersion')
    if build:
        return build.split()[0]
    return 'unknown'


def main() -> None:
    """Service entry point — called from service.py."""
    try:
        addon = xbmcaddon.Addon()
        version_str = addon.getAddonInfo('version')
        parse_version(version_str)  # Validate version string early
        log = get_logger('service')

        log.info(
            "Service started",
            event="service.start",
            version=version_str,
            device=_get_device_name(),
            kodi=_get_kodi_version()
        )

        daemon = ServiceDaemon(addon=addon, logger=log)
        daemon.load_initial_settings()
        daemon.initialize()
        daemon.run()

        log.info(
            "Service stopped",
            event="service.stop",
            version=version_str,
            device=_get_device_name()
        )
    except SystemExit:
        pass
    except Exception:
        try:
            log = get_logger('service')
            log.exception("Unhandled error in EasyTV service", event="service.crash")
        except Exception:
            import traceback
            xbmc.log(f"[EasyTV] Service crash: {traceback.format_exc()}", xbmc.LOGERROR)
    finally:
        StructuredLogger.shutdown()
