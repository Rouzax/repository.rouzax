# EasyTV TODO

<!-- Local only, gitignored. One item per section: goal, why, starting points. -->

---

## Inconsistent S01E01 casing in browse view

**Goal:** Standardize the episode notation (e.g. S01E01) to consistent uppercase everywhere.

**Why:** Two code paths format `EpisodeNo` differently. The browse view shows uppercase or lowercase depending on which path last wrote the window property.

**Starting points:**

- `resources/lib/service/episode_tracker.py:270`: `f"S{season}E{episode}"` (uppercase, initial load)
- `resources/lib/data/storage.py:672`: `f"s{season_num}e{episode_num}"` (lowercase, sync refresh)

Fix: change `storage.py:672` to uppercase to match `episode_tracker.py`.

---

## Skipped episodes shows -1 with multisync enabled

**Goal:** Prevent the skipped episodes count from displaying -1 in the browse view when shared database sync is active.

**Why:** With multisync on, the skipped count occasionally drops to -1. A restart resets it to 0, suggesting a timing or stale-data issue where the unwatched/ondeck counts get out of sync during a sync refresh.

**Starting points:**

- `resources/lib/ui/browse_window.py:274-280`: skipped = `unwatched - ondeck`, no floor at 0
- `resources/lib/data/storage.py:690-694`: counts come from `db_data` during sync refresh
- Likely cause: `unwatched_count` and `ondeck` list update at different times during sync, so `ondeck > unwatched` briefly

---

