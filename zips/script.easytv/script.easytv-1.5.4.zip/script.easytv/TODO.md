# EasyTV TODO

<!-- Local only, gitignored. One item per section: goal, why, starting points. -->

---

## First Episode Only Mode (Watched Playlists)

**Source:** DJ_Izumi, Kodi Forum

**Goal:** When "watched only" episode selection generates a random playlist, add an option to always pick S01E01 (or the earliest available episode) instead of a random watched episode.

**Why:** "Sampler platter" for guests. Random shows, but always the pilot so people can decide if they want to watch more. Mid-series drops don't work for serialized content. Random episodes are still fine for non-episodic shows (Mythbusters), so both modes have value.

**What we know:**
- Only applies to `episode_selection=1` (watched only) in random playlists
- Fall back to earliest available episode if S01E01 is missing from the library
- S01E01 does not need to be watched itself; the show just needs watched episodes
- No tracking/state changes needed; purely a playlist episode selection change

**Open questions:**
- Per-show vs. global toggle? DJ_Izumi's framing suggests global is fine
- Interaction with "Both" mode (`episode_selection=2`): should the watched portion also respect this?
- Behavior with `multiple_shows=true`: playing S01E01 of the same show repeatedly doesn't make sense

**Starting points:**
- `resources/lib/playback/random_player.py`: `_fetch_random_episode_for_show()` selects random watched episodes
- `resources/lib/data/queries.py`: `build_random_episodes_query()` builds the JSON-RPC query
- Existing premiere filtering (`_check_premiere_exclusion`) is unrelated; it only applies to the unwatched flow

---

## Episode-Level Smart Playlist Filtering

**Source:** DJ_Izumi, Kodi Forum (same thread)

**Goal:** Allow episode-type smart playlists to control which episodes are eligible for random playlists, not just which shows.

**Why:** Currently filtering works at the series level only. DJ_Izumi wants things like: Simpsons restricted to seasons 1-14, or all shows filtered to episodes with "Christmas" in the title for a holiday-themed clone.

**What we know:**
- `extract_showids_from_playlist()` reads `.xsp` files and extracts show IDs only
- Episode selection happens downstream per-show with no playlist-level episode filtering
- This is a bigger change than the first-episode feature

**Tested against laptop3 Kodi instance (2025-06-03):**
- Created `Test - First Episodes Only.xsp` (`type="episodes"`, rules: season=1, episode=1, playcount>0)
  Returned 20 watched S01E01 episodes from 20 unique shows. Numeric filtering works.
- Created `Test - Christmas Episodes.xsp` (`type="episodes"`, rules: title/plot contains "Christmas")
  Returned 26 episodes across 18 shows. Text/plot filtering works.
- `Files.GetDirectory` with the `.xsp` path returns individual episodes (not shows)
- Each result has `type: "episode"`, `id` (episode ID), `tvshowid`, `label`, and `file`
- `Files.GetDirectory` does NOT support all episode properties; `season`, `episode`, `showtitle`,
  `playcount` fail with "Invalid params". Only `tvshowid` (and standard file fields) work.
  To get full episode details, follow up with `VideoLibrary.GetEpisodeDetails` per episode.
- Conclusion: Kodi's smart playlist engine handles all the filtering; EasyTV just needs to
  detect the playlist type and route the episode-level results into the playlist builder

**Why this doesn't work yet:**
EasyTV's architecture assumes "filter shows first, pick episodes per-show second." Episode-level
filtering inverts that flow. Specific blockers:
- `extract_showids_from_playlist()` hardcodes `type == 'tvshow'` filtering, so episode-type
  playlist results are silently discarded
- `filter_shows_by_population()` only accepts a show ID list, not a pre-filtered episode list
- `_fetch_random_episode_for_show()` would need to be bypassed when specific episodes are
  already provided by the playlist
- Settings UI only allows selecting show-type playlists

**Open questions:**
- Accept episode-type `.xsp` playlists alongside show-type, extracting both show IDs and eligible episode IDs?
- Or add native season/episode range filters as settings (simpler but less flexible)?
- Interaction with existing per-show episode selection (unwatched/watched/both)

**Starting points:**
- `resources/lib/data/shows.py`: `extract_showids_from_playlist()` (show-level extraction)
- `resources/lib/playback/random_player.py`: `filter_shows_by_population()`
- `resources/settings.xml`: show filtering section

---

## Skipped episodes shows -1 with multisync enabled

**Goal:** Prevent the skipped episodes count from displaying -1 in the browse view when shared database sync is active.

**Why:** With multisync on, the skipped count occasionally drops to -1. A restart resets it to 0, suggesting a timing or stale-data issue where the unwatched/ondeck counts get out of sync during a sync refresh.

**Starting points:**

- `resources/lib/ui/browse_window.py:274-280`: skipped = `unwatched - ondeck`, no floor at 0
- `resources/lib/data/storage.py:690-694`: counts come from `db_data` during sync refresh
- Likely cause: `unwatched_count` and `ondeck` list update at different times during sync, so `ondeck > unwatched` briefly

---

